import numpy as np

A = np.array([2, 4, 6])
B = np.array([1, 3, 5])

addition = A + B
scalar = 3
scalar_multiplication = scalar * A
dot_product = np.dot(A, B)

print("Vector A:", A)
print("Vector B:", B)
print("Addition:", addition)
print("Scalar Multiplication:", scalar_multiplication)
print("Dot Product:", dot_product)
