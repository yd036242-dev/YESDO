import numpy as np

A = np.array([[4, 2],
              [3, 1]])

B = np.array([[1, 2, 3],
              [2, 4, 6],
              [3, 6, 9]])

det_A = np.linalg.det(A)
rank_A = np.linalg.matrix_rank(A)
rank_B = np.linalg.matrix_rank(B)

print("Determinant of A:", det_A)
print("Rank of A:", rank_A)
print("Rank of B:", rank_B)
