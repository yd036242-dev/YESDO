import numpy as np

A = np.array([3, 4])
B = np.array([6, 8])

l1_norm = np.linalg.norm(A, ord=1)
l2_norm = np.linalg.norm(A)
distance = np.linalg.norm(A - B)

print("L1 Norm:", l1_norm)
print("L2 Norm:", l2_norm)
print("Euclidean Distance:", distance)
