# Linear Algebra for Machine Learning – Lab

This repository contains Python programs for the Linear Algebra for Machine Learning Lab practicals.

## Practicals

1. Vector Operations
2. Vector Norms and Distance
3. Matrix Operations
4. Determinant and Rank
5. Solving Linear Equations
6. Eigenvalues and Eigenvectors
7. Principal Component Analysis (PCA)
8. Singular Value Decomposition (SVD)
9. Vector Transformation

## Technologies Used

- Python
- NumPy
- Matplotlib
- Scikit-learn

## Course

Linear Algebra for Machine Learning – Lab
Course Code: BSAILB302P
