import numpy as np

A = np.array([[1, 2],
              [3, 4]])

B = np.array([[5, 6],
              [7, 8]])

addition = A + B
multiplication = A @ B
transpose = A.T
inverse = np.linalg.inv(A)

print("Addition:")
print(addition)

print("Multiplication:")
print(multiplication)

print("Transpose:")
print(transpose)

print("Inverse:")
print(inverse)
